$apiKey = '< YOUR_PRIVATE_KEY >';
$request = new Paymill\Request($apiKey);

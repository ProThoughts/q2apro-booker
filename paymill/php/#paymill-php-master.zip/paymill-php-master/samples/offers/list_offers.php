$offer = new Paymill\Models\Request\Offer();

$response = $request->getAll($offer);

$client = new Paymill\Models\Request\Client();

$response = $request->getAll($client);

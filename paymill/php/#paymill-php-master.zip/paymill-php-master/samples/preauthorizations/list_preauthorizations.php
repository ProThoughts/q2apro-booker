$preAuth = new Paymill\Models\Request\Preauthorization();

$response = $request->getAll($preAuth);

$refund = new Paymill\Models\Request\Refund();

$response = $request->getAll($refund);

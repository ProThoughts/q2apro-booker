$transaction = new Paymill\Models\Request\Transaction();

$response = $request->getAll($transaction);

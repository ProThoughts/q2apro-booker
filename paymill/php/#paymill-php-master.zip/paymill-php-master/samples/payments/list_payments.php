$payment = new Paymill\Models\Request\Payment();

$response = $request->getAll($payment);
